#This is the only file you need to work on. You do NOT need to modify other files

# Below are the functions you need to implement. For the first project, you only need to finish implementing iddfs() 
# ie iterative deepening depth first search


# here you need to implement the Iterative Deepening Search Method
def iterativeDeepening(puzzle):
    list = []
    return list


# This will be for next project
def astar(puzzle):
    list = []
    return list








